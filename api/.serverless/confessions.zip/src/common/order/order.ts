import { OrderDirection } from './order-direction';

export abstract class Order {
  direction: OrderDirection;
}
