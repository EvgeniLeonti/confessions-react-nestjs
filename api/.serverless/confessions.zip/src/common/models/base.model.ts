export abstract class BaseModel {
  id: string;

  createdAt: Date;

  updatedAt: Date;
}
